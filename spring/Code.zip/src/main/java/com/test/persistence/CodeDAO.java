package com.test.persistence;

public interface CodeDAO {

}
