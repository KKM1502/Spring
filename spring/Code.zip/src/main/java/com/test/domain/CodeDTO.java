package com.test.domain;

import lombok.Data;

@Data
public class CodeDTO {

	private String seq;
	private String subject;
	private String code;
	private String regdate;
	private String language;
	
}
